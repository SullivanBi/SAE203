unsigned long Time= 0UL;
bool ledcolor=true;
ChainableLED leds(D2, D3, 1);

void ledAlarm(){
  if(millis() - Time > 200)
  {
    if(ledcolor)
      ledcolor=false;
    else
      ledcolor=true;
 	  Time=millis();
  }  

  if(ledcolor)
  {
    leds.setColorRGB(0, 255, 0, 0);
  }
  else
  {
    leds.setColorRGB(0, 0, 0, 255);
  }
}