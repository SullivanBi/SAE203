#define SPEAKER 26
bool al=false;

unsigned long Time2=0UL;
int melody[]={1702,1702,851,1136,1203,1275,1431,1702,1431,1275};
int duration[]={125, 125, 250, 250, 125, 250, 250, 125, 125, 125};
int del[]={ 125, 125, 250, 375, 250, 250, 250, 125, 125, 125};

void sound(uint8_t note_index)
{
    for(int i=0;i<100;i++)
    {
        digitalWrite(SPEAKER,HIGH);
        delayMicroseconds(melody[note_index]);
        digitalWrite(SPEAKER,LOW);
        delayMicroseconds(melody[note_index]);
    }
}

void PlaySong(){
  for(int i=0;i<sizeof(melody)/sizeof(int);)
  {
    sound(i);
    if(millis()-Time2>del[i])
    {
      i++;
      Time2=millis();
    }
  }
  al=false;
}
