#define A0 26
#define A1 25
#define A2 34
#define A3 39
#define A4 36
#define A5 4

#define D2 14
#define D3 32
#define D4 15
#define D5 33

#define RX RX
#define TX TX

#define SCL 22
#define SDA 23

#define LED_BUILTIN 13